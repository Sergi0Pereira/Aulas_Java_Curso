package Trabalho;

public class MainDarRunAqui extends Menu   {

    public static void main(String[] args) {
        

        Menu principal = new Menu();
        principal.Menu();

    }


     
}
