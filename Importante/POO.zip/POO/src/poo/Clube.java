package poo;

import java.util.Scanner;
import java.util.ArrayList;

public class Clube {

    Scanner in = new Scanner(System.in);

    public ArrayList<Object> informacao = new ArrayList<Object>();

    String nome, pais, cidade;
    int capital,  titulos;
    final int socios=10000;
    
    static void apresentacao(){
        System.out.println("Aqui estao os clubes!");
    }

    public String Nome(int num ,String nome) {
        informacao.add(nome);
        System.out.println("O "+num+" clube é o: "+nome);
        return nome;
    }

    public String Pais(String pais) {
        informacao.add(pais);
        return pais;
    }

    public String Cidade(String cidade) {
        informacao.add("Cidade: "+cidade);
        return cidade;
    }

    public int capital() {  
        informacao.add(capital);
        return capital;
    }

    public void socios(int socios) {
        informacao.add(socios);
    }
    

    public void titulos() {

        System.out.println("Quantos titulos tem o seu Clube?");
        this.titulos = in.nextInt();
        informacao.add(titulos);

    }

    public String impressao() {
        String impressao;
        impressao = "Aqui estao as informacoes do seu clube:\n"+ informacao;
        return impressao; // O que a variavel devolve
    }
    
    

}
