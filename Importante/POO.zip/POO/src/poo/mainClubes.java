package poo;

public class mainClubes {

    public static void main(String[] args) {

        Clube Porto = new Clube();
        Clube Benfica = new Clube();

        Clube.apresentacao();// metodo apresentacao é static. Assim sendo, nao necessita de um objeto
        // para ser invocado mas sim da classe.

        Porto.Nome(1, "FcPorto");
        Benfica.Nome(2, "Benfica");
        Porto.Cidade("Porto");
        Porto.Pais("Portugal");

        // Benfica.capital(2000);  metodo que nao recebe argumentos, dai o erro no main quando se atribui
        // argumento no entanto é possi vels redefinir o seu valor como se ve aqui em baixo no objeto Porto
        Porto.capital = 5000; // alteraçao do valor da variavel capital no objecto Porto ( os valores das
        // variaveis sao independentes do objecto
        Porto.capital();

        // Porto.socios=10000; Aqui nao é possivel alterar porque a variavel porque está definida como final
        Porto.titulos();// Metodo que pede input

        String informacao = Porto.impressao(); // atribuiçao de uma variavel a um metodo com retorno(o que ela devolve
        // por exemplo num print)
        System.out.println(Porto.impressao());

    }
}
