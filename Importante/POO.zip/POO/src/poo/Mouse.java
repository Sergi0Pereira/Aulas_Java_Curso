package poo;

public class Mouse {

    private int age;
    private double weight;
    private double pgr;
    

    public int getAge() {
        return this.age;
    }

    public double getWeight() {
        return this.weight;
    }

    /**
     * *
     * Metodo que define o grau do crescimento do rato
     *
     * @param pgr
     */
    public void setpgr(double pgr) {
        this.pgr = pgr;
    }

    /**
     * *
     * Metodo que define o Crescimento
     * @param days
     */
    public void grow(int days) {
//        for (int i = 0; i < days; i++) {
//            this.weight += (.01 * this.pgr * this.weight);
//        }
//
//        this.age += days;

        int endAge =this.age+days;
        
        while(this.age>=100){
            return;
        }
        this.weight += (.01 * this.pgr * this.weight);
        this.age++;
    }

    /**
     * *
     * Metodo que apresenta os dados do Rato
     */
    public void display() {
        System.out.println("Age: " + this.age + "Weight: \n" + this.weight);
    }
    
    
}

        
}
