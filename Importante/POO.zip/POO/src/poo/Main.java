package poo;

import java.util.Scanner;

public class Main{
    
    public static void main(String [] args){
            Scanner in=new Scanner(System.in);
        Mouse mickey= new Mouse();
        
        
        System.out.println("Insira aqui a percentagem de Crescimento do seu rato:");
        double pgr=in.nextDouble();
        
        System.out.println("Inserir o numero de dias para crescer: ");
        int days=in.nextInt();
        
        mickey.setpgr(pgr);
        mickey.grow(days);
        mickey.display();
        
        
        
        
        
        
    
    }
}