package calculadora;

public class Main extends Calculadora{
    
    public static void main(String [] args) throws Exception{
    
        Calculadora um= new Calculadora();
        um.Calculadora();
 
    }
}